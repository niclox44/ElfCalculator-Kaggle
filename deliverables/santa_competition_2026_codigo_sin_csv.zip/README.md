# Santa 2026 — The Elf Calculator

Proyecto de optimización para construir los 1.000 programas aritméticos de la competición con el menor número total de instrucciones.

## Estructura

- `data/`: archivos originales de Kaggle.
- `src/structure_detector.py`: detector de familias estructurales.
- `src/tiny_solver.py`: solucionador exacto para puzzles `tiny`.
- `src/power_basis_solver.py`: construcción con potencias de dos compartidas.
- `src/signed_digit_solver.py`: representaciones binarias y NAF compartidas.
- `src/anchor_difference_solver.py`: objetivos como ancla más/menos diferencia.
- `src/multiplicative_solver.py`: reutilización de un factor común.
- `src/multifactor_solver.py`: reutilización de varios factores y cocientes.
- `src/recursive_anchor_solver.py`: anclas y diferencias en dos niveles.
- `src/deep_anchor_solver.py`: selección entre tres y cuatro niveles de anclas.
- `src/validate_submission.py`: validador independiente de envíos completos.
- `reports/`: análisis y detalle de soluciones.
- `submissions/`: archivos CSV completos listos para enviar.

Todo el código actual usa únicamente la biblioteca estándar de Python.

## Estado actual

- Puntuación de la solución base: `1,490,379`.
- Puntuación tras resolver exactamente los 16 puzzles `tiny`: `1,490,270`.
- Puntuación con potencias de dos compartidas: `547,572`.
- Puntuación con dígitos binarios/NAF: `439,527`.
- Puntuación con anclas y diferencias: `399,864`.
- Puntuación tras factores múltiples: `397,499`.
- Puntuación con anclas recursivas de dos niveles: `376,815`.
- Mejor puntuación local, con tres/cuatro niveles: `363,056`.
- Mejora acumulada frente a la solución base: `1,127,323` instrucciones (`75.64 %`).
- Los 1.000 programas se validan localmente contra las reglas del concurso.
- Máximo por puzzle: `674` instrucciones; máximo por celda: `9,645` bytes.

## Regenerar la clasificación estructural

```bash
python3 src/structure_detector.py \
  --practice data/practice_puzzles.csv \
  --scored data/puzzles.csv \
  --output reports/structure_report.json
```

## Regenerar el envío con soluciones `tiny` óptimas

```bash
python3 src/tiny_solver.py \
  --puzzles data/puzzles.csv \
  --baseline data/sample_submission.csv \
  --output submissions/submission_tiny_exact.csv \
  --solutions reports/tiny_exact_solutions.csv
```

## Validar un envío

```bash
python3 src/validate_submission.py \
  --puzzles data/puzzles.csv \
  --submission submissions/submission_tiny_exact.csv
```

El validador comprueba identificadores, formato JSON, operaciones, registros, divisiones exactas, valores máximos, objetivos cubiertos, número de instrucciones y tamaño de cada celda.

## Regenerar el envío con potencias compartidas

Este solucionador reutiliza cada potencia de dos entre todos los objetivos del puzzle y conserva las soluciones `tiny` cuando son más cortas.

```bash
python3 src/power_basis_solver.py \
  --puzzles data/puzzles.csv \
  --current submissions/submission_tiny_exact.csv \
  --output submissions/submission_power_basis.csv \
  --report reports/power_basis_report.json
```

## Regenerar las mejoras sucesivas

Cada etapa conserva, puzzle por puzzle, el programa más corto de la etapa
anterior. Los comandos completos están reflejados en los propios scripts; la
última etapa se regenera así:

```bash
python3 src/deep_anchor_solver.py \
  --puzzles data/puzzles.csv \
  --current submissions/submission_recursive_anchor.csv \
  --output submissions/submission_deep_anchor.csv \
  --report reports/deep_anchor_report.json
```

## Validar el mejor envío actual

```bash
python3 src/validate_submission.py \
  --puzzles data/puzzles.csv \
  --submission submissions/submission_deep_anchor.csv
```

El ZIP para Kaggle debe contener únicamente `submission_deep_anchor.csv`.
